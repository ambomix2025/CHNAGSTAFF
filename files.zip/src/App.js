import React, { useState } from "react";
import IDCardForm from "./components/IDCardForm";
import IDCardPreview from "./components/IDCardPreview";
import Cropper from "react-easy-crop";
import getCroppedImg from "./utils/cropImage";

function App() {
  const [details, setDetails] = useState(null);
  const [imageSrc, setImageSrc] = useState(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);
  const [croppedImage, setCroppedImage] = useState(null);

  const handleDetailsSubmit = ({ name, phone, photo }) => {
    setDetails({ name, phone });
    setImageSrc(photo);
  };

  const onCropComplete = (_, croppedAreaPixels) => {
    setCroppedAreaPixels(croppedAreaPixels);
  };

  const showCroppedImage = async () => {
    try {
      const croppedImg = await getCroppedImg(imageSrc, croppedAreaPixels);
      setCroppedImage(croppedImg);
    } catch (e) {
      alert("Failed to crop: " + e);
    }
  };

  // Step 1: Input form
  if (!details) {
    return <IDCardForm onDetailsSubmit={handleDetailsSubmit} />;
  }

  // Step 2: Crop photo
  if (imageSrc && !croppedImage) {
    return (
      <div style={{ height: 400, width: 300, position: "relative" }}>
        <Cropper
          image={imageSrc}
          crop={crop}
          zoom={zoom}
          aspect={7 / 9}
          onCropChange={setCrop}
          onZoomChange={setZoom}
          onCropComplete={onCropComplete}
        />
        <button onClick={showCroppedImage} style={{ marginTop: 20 }}>
          Crop and Preview
        </button>
      </div>
    );
  }

  // Step 3: Preview and Download
  if (details && croppedImage) {
    return (
      <IDCardPreview
        details={details}
        croppedImage={croppedImage}
      />
    );
  }
}

export default App;