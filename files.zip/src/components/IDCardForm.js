import React, { useState } from "react";

const IDCardForm = ({ onDetailsSubmit }) => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [photo, setPhoto] = useState(null);

  const handlePhotoChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => setPhoto(ev.target.result);
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onDetailsSubmit({ name, phone, photo });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input value={name} onChange={e => setName(e.target.value)} required />
      </label>
      <br />
      <label>
        Phone:
        <input value={phone} onChange={e => setPhone(e.target.value)} required />
      </label>
      <br />
      <label>
        Photo:
        <input type="file" accept="image/*" onChange={handlePhotoChange} required />
      </label>
      <br />
      <button type="submit">Next</button>
    </form>
  );
};

export default IDCardForm;