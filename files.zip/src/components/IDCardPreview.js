import React, { useRef } from "react";
import { toPng } from "html-to-image";

const COMPANY_NAME = "HOME RANGE FACTORY";
const TAGLINE = "FOLLOWING A FREELANCE VENTURE FOR ALL HOUSEWIVES IN KERALA";

const IDCardPreview = ({ details, croppedImage, onDownload }) => {
  const cardRef = useRef();

  const handleDownload = () => {
    toPng(cardRef.current).then((dataUrl) => {
      const link = document.createElement("a");
      link.download = `${details.name}_id_card.png`;
      link.href = dataUrl;
      link.click();
    });
    if (onDownload) onDownload();
  };

  return (
    <div>
      <div
        ref={cardRef}
        style={{
          width: 350,
          height: 220,
          border: "2px solid #0057b8",
          borderRadius: 12,
          overflow: "hidden",
          fontFamily: "Arial, sans-serif",
          background: "#fff",
          position: "relative",
        }}
      >
        {/* Blue area for company details */}
        <div
          style={{
            background: "#0057b8",
            color: "#fff",
            padding: "10px 15px 5px 15px",
            textAlign: "center",
          }}
        >
          <h2 style={{ margin: 0, fontSize: 20 }}>{COMPANY_NAME}</h2>
          <div style={{ fontSize: 12 }}>{TAGLINE}</div>
        </div>
        {/* Photo and user details */}
        <div style={{ display: "flex", padding: 15 }}>
          <div>
            {croppedImage && (
              <img
                src={croppedImage}
                alt="user"
                style={{
                  width: 70,
                  height: 90,
                  objectFit: "cover",
                  borderRadius: 6,
                  border: "2px solid #0057b8"
                }}
              />
            )}
          </div>
          <div style={{ marginLeft: 20, alignSelf: "center" }}>
            <div style={{ fontWeight: "bold", fontSize: 16 }}>{details.name}</div>
            <div style={{ fontSize: 14, marginTop: 4 }}>{details.phone}</div>
          </div>
        </div>
      </div>
      <button style={{ marginTop: 20 }} onClick={handleDownload}>
        Download ID Card
      </button>
    </div>
  );
};

export default IDCardPreview;