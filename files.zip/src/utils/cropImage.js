// Utility to crop image using canvas, compatible with react-easy-crop
export default function getCroppedImg(imageSrc, crop) {
  const createImage = url =>
    new Promise((resolve, reject) => {
      const img = new window.Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = error => reject(error);
      img.src = url;
    });

  return new Promise(async (resolve, reject) => {
    const image = await createImage(imageSrc);
    const canvas = document.createElement("canvas");
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext("2d");

    ctx.drawImage(
      image,
      crop.x,
      crop.y,
      crop.width,
      crop.height,
      0,
      0,
      crop.width,
      crop.height
    );
    canvas.toBlob(blob => {
      if (!blob) return reject("Canvas is empty");
      const fileUrl = window.URL.createObjectURL(blob);
      resolve(fileUrl);
    }, "image/png");
  });
}